package client;

import controller.Controller;

public class Client {
	public static void main(String[] args) {
		Controller app = new Controller();
		app.startApp();
	}
}
